﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_Alpha_Moonbase_Simulation
{
    public partial class FormMain2 : Form
    {
        public FormMain2(string from1)
        {
            InitializeComponent();
            TFF1Tb.Text = from1; // receives string from Form

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMain Form = new FormMain(textBox2.Text); // sends text to Form
            this.Hide();
            Form.Show();
        }

       

        private void button5_Click(object sender, EventArgs e) // This west button / Cafe
        {
            this.changeroom(0);
        }

        private void button4_Click(object sender, EventArgs e) // This is East button / Control Room
        {
            this.changeroom(1);
        }

        private void button3_Click(object sender, EventArgs e) // this is South button / S.Bedroom
        {
            this.changeroom(2);
        }

        private void button2_Click(object sender, EventArgs e) // This is North button / Labratory
        { // The code below will give an error to the user the number below is  6
       
            this.changeroom(3);
        }
        private string[,] rooms = // Room Descriptions

        {
            {"Cafe","A place for relaxation, food  drinks, music and it has a great view." },
            {"Control","The control room is where activity, process and systems are monitored and directed." },
            {"Bedroom","A celestial but conventional environment while bunking in a moonbase on the moon. The bedroom delivers a warmth and tranquility" },
            {"Labratory","The lab uses robots to perform samples of cultures that are found on the moon such as soil and small life forms ." },
            {"Landcrusier","Placeholder" }

        };
        private Image[] backgroundImageS = { Properties.Resources.Cafeteria, Properties.Resources.controlroom, Properties.Resources.bedroom, Properties.Resources.RoboLAB, Properties.Resources.superneutral_art }; // Room Array
        private void changeroom(int index)

        {    
            if (index < 0 || index >= backgroundImageS.Length)


            {
                MessageBox.Show(index + " Is not a valid index!");

            }
            else 
            {   
                textBox1.Text = rooms[index, 0];

                richTextBox1.Text = rooms[index,1];
                this.BackgroundImage = backgroundImageS[index];
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e) // Exhinit; VR room, land cruseir simulation
        {
            this.changeroom(4);
        }
    }  
}

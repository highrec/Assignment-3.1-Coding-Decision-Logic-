﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_Alpha_Moonbase_Simulation
{
    public partial class FormMain : Form // name changes to Form
    {
        public FormMain(string from2 = "") 
        {
            InitializeComponent();
            textBox3.Text = from2; // Receives string FromrMain2 / Initialization
        }

        private Random random; // controls the if random 

        

        private void button1_Click_1(object sender, EventArgs e) // This is a buton click 
        {
            MessageBox.Show("Welcome to Calrissian' Moonbase!"); // Message pop-up
        }

        private void button2_Click(object sender, EventArgs e) // this is a button click
        {
            if (int.TryParse(textBox1.Text, out int value)) // conditional 
            {
                if (value <= 5)
                    MessageBox.Show("Proceed to Moonbase Bunker Room Number"); // Pop-up message

                if (value > 5)
                {
                    MessageBox.Show("Access Denied! Please Try Again!"); // Pop-up message
                }
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e) // Checkbox shows image below
        {
           Image Asuit = Image.FromFile("Asuit.jpg");
           pictureBox1.Image = Asuit;
        }

       private void checkBox2_CheckedChanged(object sender, EventArgs e) // Checkbox shows image below
        {
            Image superneutral_art = Image.FromFile("superneutral_art.png");
            pictureBox1.Image = superneutral_art;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e) // Checkbox shows image below
        {
            Image RoboLab = Image.FromFile("RoboLab.png");
            pictureBox1.Image = RoboLab;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e) // Checkbox shows image below
        {
            Image Spacestation = Image.FromFile("Spacestation.png");
            pictureBox1.Image =Spacestation;
        }

        private void button2_Click_1(object sender, EventArgs e) // Hides this form1.cs, shows new Form2.cs
        {
            FormMain2 Form = new FormMain2(textBox2.Text);
            this.Hide();
            Form.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e) // receives text only
        {

        }


        private void label2_Click(object sender, EventArgs e) // label titled TEXT ONLY
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }   

        
}   
